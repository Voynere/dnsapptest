package com.example.dnsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
